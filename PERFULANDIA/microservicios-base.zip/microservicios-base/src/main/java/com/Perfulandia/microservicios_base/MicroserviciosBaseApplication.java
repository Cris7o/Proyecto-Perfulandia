package com.Perfulandia.microservicios_base;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviciosBaseApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviciosBaseApplication.class, args);
	}

}
