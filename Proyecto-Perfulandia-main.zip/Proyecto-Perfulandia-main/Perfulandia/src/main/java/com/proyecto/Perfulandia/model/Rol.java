package com.proyecto.Perfulandia.model;

public enum Rol {
    ADMIN,
    GERENTE,
    VENTAS,
    LOGISTICA

}
